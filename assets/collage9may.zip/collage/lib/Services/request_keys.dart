class RequestKeys {
  static String Cpassword = 'confirm_password';
  static String Otp = 'otp';
  static String userId = 'user_id';
  static String password = 'password';
  static String email = 'email';
  static String mobile = 'mobile';

  static String newPassword = 'new';
  static String lname = 'lastname';
  static String fname = 'firstname';
  static String userid = 'user_id';
  static String firstname = 'first_name';
  static String lastname = 'last_name';
  static String city = 'city';
  static String photographertype = 'photographer_type';
  static String companyname = 'compny_name';
  static String perdaycharge = 'per_day_charges';
  static String type = 'type';
}