
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:kolazz_book/Models/first_veryfy_otp_response.dart';
import 'package:kolazz_book/Models/forgot_password.dart';
import 'package:kolazz_book/Models/login_response.dart';
import 'package:kolazz_book/Models/resister_user_response.dart';
import 'package:kolazz_book/Models/verify_otp.dart';

import '../Models/add_photographermodel.dart';
import 'api_client.dart';
import 'api_methods.dart';

class Api {
  final ApiMethods _apiMethods = ApiMethods();
  final ApiClient _apiClient = ApiClient();

  static final Api _api = Api._internal();

final Connectivity connectivity = Connectivity();

  //final Connectivity? connectivity;

  factory Api() {
    return _api;
  }

  Api._internal();

  Map<String, String> getHeader() {
    return {'Cookie': 'ci_session=c35fa031f74710f20bf26fea3b4ccd7bfe18332a'};
    // return {'Content-Type': 'application/json'};
  }

  // Future<RegisterUserResponse> registerUserApi(Map<String, String> body) async {
  //   if (await connectivity.checkConnectivity() == ConnectivityResult.wifi ||
  //       await connectivity.checkConnectivity() == ConnectivityResult.mobile) {
  //     String res =
  //     await _apiClient.postMethod(method: _apiMethods.registerUser, body: body);
  //     if (res.isNotEmpty) {
  //       try {
  //         return registerUserResponseFromJson(res);
  //       } catch (e) {
  //         if (kDebugMode) {
  //           print(e);
  //         }
  //         return RegisterUserResponse(error: true, message: e.toString());
  //       }
  //     } else {
  //       return RegisterUserResponse(error: true, message: 'Something went wrong');
  //     }
  //   } else {
  //     return RegisterUserResponse(error: true, message: 'No Internet');
  //   }
  // }

  Future<LoginResponseModel> loginUserApi(Map<String, String> body) async {
    if (await connectivity.checkConnectivity() == ConnectivityResult.wifi ||
        await connectivity.checkConnectivity() == ConnectivityResult.mobile) {
      String res =
      await _apiClient.postMethod(method: _apiMethods.login, body: body);
      if (res.isNotEmpty) {
        try {
          return loginResponseModelFromJson(res);
        } catch (e) {
          if (kDebugMode) {
            print(e);
          }
          return LoginResponseModel(error: true, message: e.toString(), );
        }
      } else {
        return LoginResponseModel(error: true, message: 'Something went wrong', );
      }
    } else {
      return LoginResponseModel(error: true, message: 'No Internet',);
    }
  }

  Future<RegisterUserResponse> registerUpi(Map<String, String> body) async {
    if (await connectivity.checkConnectivity() == ConnectivityResult.wifi ||
        await connectivity.checkConnectivity() == ConnectivityResult.mobile) {
      String res =
      await _apiClient.postMethod(method: _apiMethods.registerUser, body: body);
      if (res.isNotEmpty) {
        try {
          return registerUserResponseFromJson(res);
        } catch (e) {
          if (kDebugMode) {
            print(e);
          }
          return RegisterUserResponse(error: true, message: e.toString(), );
        }
      } else {
        return RegisterUserResponse(error: true, message: 'Something went wrong', );
      }
    } else {
      return RegisterUserResponse(error: true, message: 'No Internet',);
    }
  }

  Future<ResendOtpResponse> resendOTPApi(Map<String, String> body) async {
    if (await connectivity.checkConnectivity() == ConnectivityResult.wifi ||
        await connectivity.checkConnectivity() == ConnectivityResult.mobile) {
      String res =
      await _apiClient.postMethod(method: _apiMethods.sendOtp, body: body);
      if (res.isNotEmpty) {
        try {
          return resendOtpResponseFromJson(res);
        } catch (e) {
          if (kDebugMode) {
            print(e);
          }
          return ResendOtpResponse(error: true, message: e.toString(), );
        }
      } else {
        return ResendOtpResponse(error: true, message: 'Something went wrong', );
      }
    } else {
      return ResendOtpResponse(error: true, message: 'No Internet',);
    }
  }

  Future<VerifyOtpResponse> verifyOTPApi(Map<String, String> body) async {
    if (await connectivity.checkConnectivity() == ConnectivityResult.wifi ||
        await connectivity.checkConnectivity() == ConnectivityResult.mobile) {
      String res =
      await _apiClient.postMethod(method: _apiMethods.OtpVerify, body: body);
      if (res.isNotEmpty) {
        try {
          return verifyOtpResponseFromJson(res);
        } catch (e) {
          if (kDebugMode) {
            print(e);
          }
          return VerifyOtpResponse(error: true, message: e.toString(), );
        }
      } else {
        return VerifyOtpResponse(error: true, message: 'Something went wrong', );
      }
    } else {
      return VerifyOtpResponse(error: true, message: 'No Internet',);
    }
  }



Future<ForgotPassword> resetPasswordApi(Map<String, String> body) async {
    if (await connectivity.checkConnectivity() == ConnectivityResult.wifi ||
        await connectivity.checkConnectivity() == ConnectivityResult.mobile) {
      String res =
      await _apiClient.postMethod(method: _apiMethods.forgotpassword, body: body);
      if (res.isNotEmpty) {
        try {
          return forgotPasswordFromJson(res);
        } catch (e) {
          if (kDebugMode) {
            print(e);
          }
          return ForgotPassword(status: 1, msg: e.toString());
        }
      } else {
        return ForgotPassword(status: 1, msg: 'Something went wrong');
      }
    } else {
      return ForgotPassword(status: 1, msg: 'No Internet');
    }
  }

  Future<AddPhotographer> addPhotographeApi(Map<String, String> body) async {
    if (await connectivity.checkConnectivity() == ConnectivityResult.wifi ||
        await connectivity.checkConnectivity() == ConnectivityResult.mobile) {
      String res =
      await _apiClient.postMethod(method: _apiMethods.addphotographer, body: body);
      if (res.isNotEmpty) {
        try {
          return addPhotographerFromJson(res);
        } catch (e) {
          if (kDebugMode) {
            print(e);
          }
          return AddPhotographer(error:false , message: e.toString(), );
        }
      } else {
        return AddPhotographer(error: false, message: 'Something went wrong', );
      }
    } else {
      return AddPhotographer(error: false, message: 'No Internet',);
    }
  }





}