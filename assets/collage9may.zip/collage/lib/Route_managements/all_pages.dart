import 'package:get/get.dart';
import 'package:kolazz_book/Route_managements/routes.dart';
import 'package:kolazz_book/Route_managements/screen_bindings.dart';
import 'package:kolazz_book/Views/authView/forgot_password/forgot_password_view.dart';
import 'package:kolazz_book/Views/authView/otp/otp_view.dart';
import 'package:kolazz_book/Views/dashboard/Dashboard.dart';

import '../Views/authView/login/login_view.dart';
import '../Views/authView/signup/signup_view.dart';
import '../Views/splash/splash_screen.dart';

class AllPages {
  static List<GetPage> getPages() {
    return [
      GetPage(
          name: splashScreen,
          page: () => const SplashScreen(),
          binding: ScreenBindings()),
      GetPage(
          name: loginScreen,
          page: () => const LoginScreen(),
          binding: ScreenBindings()),
      GetPage(
          name: signupScreen,
          page: () =>  SignupScreen(),
          binding: ScreenBindings()),
      GetPage(
          name: otpScreen,
          page: () => OtpScreen(),
          binding: ScreenBindings()),
      GetPage(
          name:forgotPasswordScreen,
          page: () =>ForgotPasswordScreen(),
          binding: ScreenBindings()),

      GetPage(
          name:dashbord,
          page: ()=>DashBoard(),
          binding: ScreenBindings()),
      // GetPage(
      //     name: bottomBar,
      //     page: () =>  const BottomBar(),
      //     binding: ScreenBindings()),
      //

    ];
  }
}
