

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kolazz_book/Controller/addphotographercontroller.dart';
import 'package:kolazz_book/Views/Amount_screen/client_amt.dart';
import 'package:kolazz_book/Views/freelencing_jobpost/account.dart';

import '../../Utils/colors.dart';
import '../freelencing_jobpost/allotment.dart';
import '../freelencing_jobpost/client_Jobs_screen.dart';
import '../freelencing_jobpost/frelencing_post.dart';
import '../freelencing_jobpost/team allotment.dart';


class ContactScreen extends StatefulWidget {
  const ContactScreen({Key? key}) : super(key: key);

  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {

  var selectedTime1;
  _selectStartTime(BuildContext context) async {
    final TimeOfDay? timeOfDay = await showTimePicker(
        context: context,
        useRootNavigator: true,
        initialTime: TimeOfDay.now(),
        builder: (BuildContext context, Widget? child) {
          return Theme(
            data: ThemeData.light().copyWith(
                colorScheme: ColorScheme.light(primary: Colors.black),
                buttonTheme: ButtonThemeData(
                    colorScheme: ColorScheme.light(primary: Colors.black))),
            child: MediaQuery(
                data: MediaQuery.of(context)
                    .copyWith(alwaysUse24HourFormat: false),
                child: child!),
          );
        });
    if (timeOfDay != null && timeOfDay != selectedTime1) {
      setState(() {
        selectedTime1 = timeOfDay.replacing(hour: timeOfDay.hourOfPeriod);
        startTimeController.text = selectedTime1!.format(context);
      });
    }
    var per = selectedTime1!.period.toString().split(".");
    print(
        "selected time here ${selectedTime1!.format(context).toString()} and ${per[1]}");
  }

  TextEditingController dateinput = TextEditingController();
  @override
  void initState() {
    dateinput.text = "";

    super.initState();
  }

  TextEditingController startTimeController = TextEditingController();

  bool isSelected = false;



  Widget _phptographers() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Container(
            // height: 45,
            width: MediaQuery.of(context).size.width/1,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
            child: ExpansionTile(
              trailing: Image.asset("assets/calling.png", scale: 1.1,),
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                  Text("Candid photographer", style: TextStyle(color: AppColors.textclr,fontSize: 13)),
                  Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

                ],
              ),
            children: [
              ListTile(title: Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                      InkWell(
                        onTap: () {

                          Navigator.push(context, MaterialPageRoute(builder: (context)=>freelencingPost()));

                        },
                        child: Container(

                            height: 40,
                            width: MediaQuery.of(context).size.width/2.9,
                            child: Center(
                              child: Text(
                                'Freelencing',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                ),
                              ),
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.AppbtnColor,
                              // border: Border.all(color: AppColors.AppbtnColor),
                              borderRadius: BorderRadius.circular(10),
                            )),
                      ),
                        InkWell(
                        onTap: () {

                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AllotmentScreen()));

                        },
                        child: Container(

                            height: 40,
                            width: MediaQuery.of(context).size.width/2.9,
                            child: Center(
                              child: Text(
                                'Allotment',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.contaccontainerblack,
                              // border: Border.all(color: AppColors.AppbtnColor),
                              borderRadius: BorderRadius.circular(10),
                            )),
                      ),

                    ],),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>AccountScreen()));

                      },
                      child: Container(
                          height: 45,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                          width: MediaQuery.of(context).size.width,
                          child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                      Container(
                        height: 30,
                        width: 80,
                        decoration: BoxDecoration(
                          color: AppColors.lightwhite,
                          borderRadius: BorderRadius.circular(5)
                        ),
                        child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                      ),
                      Container(
                        height: 30,
                        width: 80,
                        decoration: BoxDecoration(
                          color: AppColors.contaccontainerred,
                          borderRadius: BorderRadius.circular(5)
                        ),
                        child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                      )
                    ],)
                  ],
                ),
              )
              ),
            ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Container(
            // height: 45,
            width: MediaQuery.of(context).size.width/1,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
            child: ExpansionTile(
              trailing: Image.asset("assets/calling.png", scale: 1.1,),
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                  Text("Candid photographer", style: TextStyle(color: AppColors.textclr,fontSize: 13)),
                  Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

                ],
              ),
              children: [
                ListTile(title: Container(
                  padding: EdgeInsets.all(25),
                  decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>freelencingPost()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Freelencing',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.AppbtnColor,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>AllotmentScreen()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Allotment',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.contaccontainerblack,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),

                        ],),
                      SizedBox(height: 20,),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AccountScreen()));

                        },
                        child: Container(
                            height: 45,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                            width: MediaQuery.of(context).size.width,
                            child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                        ),
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.lightwhite,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          ),
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.contaccontainerred,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          )
                        ],)
                    ],
                  ),
                )
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Container(
            // height: 45,
            width: MediaQuery.of(context).size.width/1,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
            child: ExpansionTile(
              trailing: Image.asset("assets/calling.png", scale: 1.1,),
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                  Text("Candid photographer", style: TextStyle(color: AppColors.textclr,fontSize: 13)),
                  Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

                ],
              ),
              children: [
                ListTile(title: Container(
                  padding: EdgeInsets.all(25),
                  decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>freelencingPost()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Freelencing',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.AppbtnColor,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>AllotmentScreen()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Allotment',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.contaccontainerblack,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),

                        ],),
                      SizedBox(height: 20,),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AccountScreen()));

                        },
                        child: Container(
                            height: 45,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                            width: MediaQuery.of(context).size.width,
                            child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                        ),
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.lightwhite,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          ),
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.contaccontainerred,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          )
                        ],)
                    ],
                  ),
                )
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Container(
            // height: 45,
            width: MediaQuery.of(context).size.width/1,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
            child: ExpansionTile(
              trailing: Image.asset("assets/calling.png", scale: 1.1,),
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                  Text("Candid photographer", style: TextStyle(color: AppColors.textclr,fontSize: 13)),
                  Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

                ],
              ),
              children: [
                ListTile(title: Container(
                  padding: EdgeInsets.all(25),
                  decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>freelencingPost()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Freelencing',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.AppbtnColor,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>AllotmentScreen()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Allotment',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.contaccontainerblack,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),

                        ],),
                      SizedBox(height: 20,),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AccountScreen()));

                        },
                        child: Container(
                            height: 45,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                            width: MediaQuery.of(context).size.width,
                            child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                        ),
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.lightwhite,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          ),
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.contaccontainerred,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          )
                        ],)
                    ],
                  ),
                )
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Container(
            // height: 45,
            width: MediaQuery.of(context).size.width/1,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
            child: ExpansionTile(
              trailing: Image.asset("assets/calling.png", scale: 1.1,),
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                  Text("Candid photographer", style: TextStyle(color: AppColors.textclr,fontSize: 13)),
                  Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

                ],
              ),
              children: [
                ListTile(title: Container(
                  padding: EdgeInsets.all(25),
                  decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>freelencingPost()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Freelencing',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.AppbtnColor,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>AllotmentScreen()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Allotment',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.contaccontainerblack,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),

                        ],),
                      SizedBox(height: 20,),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AccountScreen()));

                        },
                        child: Container(
                            height: 45,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                            width: MediaQuery.of(context).size.width,
                            child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                        ),
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.lightwhite,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          ),
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.contaccontainerred,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          )
                        ],)
                    ],
                  ),
                )
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Container(
            // height: 45,
            width: MediaQuery.of(context).size.width/1,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
            child: ExpansionTile(
              trailing: Image.asset("assets/calling.png", scale: 1.1,),
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                  Text("Candid photographer", style: TextStyle(color: AppColors.textclr,fontSize: 13)),
                  Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

                ],
              ),
              children: [
                ListTile(title: Container(
                  padding: EdgeInsets.all(25),
                  decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>freelencingPost()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Freelencing',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.AppbtnColor,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>AllotmentScreen()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Allotment',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.contaccontainerblack,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),

                        ],),
                      SizedBox(height: 20,),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AccountScreen()));

                        },
                        child: Container(
                            height: 45,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                            width: MediaQuery.of(context).size.width,
                            child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                        ),
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.lightwhite,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          ),
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.contaccontainerred,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          )
                        ],)
                    ],
                  ),
                )
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Container(
            // height: 45,
            width: MediaQuery.of(context).size.width/1,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
            child: ExpansionTile(
              trailing: Image.asset("assets/calling.png", scale: 1.1,),
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                  Text("Candid photographer", style: TextStyle(color: AppColors.textclr,fontSize: 13)),
                  Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

                ],
              ),
              children: [
                ListTile(title: Container(
                  padding: EdgeInsets.all(25),
                  decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>freelencingPost()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Freelencing',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.AppbtnColor,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>AllotmentScreen()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Allotment',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.contaccontainerblack,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),

                        ],),
                      SizedBox(height: 20,),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AccountScreen()));

                        },
                        child: Container(
                            height: 45,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                            width: MediaQuery.of(context).size.width,
                            child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                        ),
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.lightwhite,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          ),
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.contaccontainerred,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          )
                        ],)
                    ],
                  ),
                )
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Container(
            // height: 45,
            width: MediaQuery.of(context).size.width/1,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
            child: ExpansionTile(
              trailing: Image.asset("assets/calling.png", scale: 1.1,),
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                  Text("Candid photographer", style: TextStyle(color: AppColors.textclr,fontSize: 13)),
                  Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

                ],
              ),
              children: [
                ListTile(title: Container(
                  padding: EdgeInsets.all(25),
                  decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>freelencingPost()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Freelencing',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.AppbtnColor,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>AllotmentScreen()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Allotment',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.contaccontainerblack,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),

                        ],),
                      SizedBox(height: 20,),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AccountScreen()));

                        },
                        child: Container(
                            height: 45,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                            width: MediaQuery.of(context).size.width,
                            child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                        ),
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.lightwhite,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          ),
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.contaccontainerred,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          )
                        ],)
                    ],
                  ),
                )
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Container(
            // height: 45,
            width: MediaQuery.of(context).size.width/1,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
            child: ExpansionTile(
              trailing: Image.asset("assets/calling.png", scale: 1.1,),
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                  Text("Candid photographer", style: TextStyle(color: AppColors.textclr,fontSize: 13)),
                  Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

                ],
              ),
              children: [
                ListTile(title: Container(
                  padding: EdgeInsets.all(25),
                  decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>freelencingPost()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Freelencing',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.AppbtnColor,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          InkWell(
                            onTap: () {

                              Navigator.push(context, MaterialPageRoute(builder: (context)=>AllotmentScreen()));

                            },
                            child: Container(

                                height: 40,
                                width: MediaQuery.of(context).size.width/2.9,
                                child: Center(
                                  child: Text(
                                    'Allotment',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.contaccontainerblack,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),

                        ],),
                      SizedBox(height: 20,),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AccountScreen()));

                        },
                        child: Container(
                            height: 45,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                            width: MediaQuery.of(context).size.width,
                            child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                        ),
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.lightwhite,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          ),
                          Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                                color: AppColors.contaccontainerred,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                          )
                        ],)
                    ],
                  ),
                )
                ),
              ],
            ),
          ),
        ),




      ],
    );
  }

  Widget _clients() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: Container(
          // height: 45,
          width: MediaQuery.of(context).size.width/1,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
          child: ExpansionTile(
            trailing: Image.asset("assets/calling.png", scale: 1.1,),
            title:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

              ],
            ),
            children: [
              ListTile(title: Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {

                            Navigator.push(context, MaterialPageRoute(builder: (context)=>FinalJobsScreen()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Final Jobs',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.AppbtnColor,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>TeamAllotment()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Team Allotment',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.contaccontainerblack,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),

                      ],),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientDetails()));

                      },
                      child: Container(
                          height: 45,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                          width: MediaQuery.of(context).size.width,
                          child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.lightwhite,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        ),
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.contaccontainerred,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        )
                      ],)
                  ],
                ),
              )
              ),
            ],
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: Container(
          // height: 45,
          width: MediaQuery.of(context).size.width/1,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
          child: ExpansionTile(
            trailing: Image.asset("assets/calling.png", scale: 1.1,),
            title:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

              ],
            ),
            children: [
              ListTile(title: Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {

                            Navigator.push(context, MaterialPageRoute(builder: (context)=>FinalJobsScreen()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Final Jobs',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.AppbtnColor,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>TeamAllotment()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Team Allotment',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.contaccontainerblack,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),

                      ],),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientDetails()));

                      },
                      child: Container(
                          height: 45,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                          width: MediaQuery.of(context).size.width,
                          child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.lightwhite,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        ),
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.contaccontainerred,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        )
                      ],)
                  ],
                ),
              )
              ),
            ],
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: Container(
          // height: 45,
          width: MediaQuery.of(context).size.width/1,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
          child: ExpansionTile(
            trailing: Image.asset("assets/calling.png", scale: 1.1,),
            title:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

              ],
            ),
            children: [
              ListTile(title: Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {

                            Navigator.push(context, MaterialPageRoute(builder: (context)=>FinalJobsScreen()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Final Jobs',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.AppbtnColor,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>TeamAllotment()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Team Allotment',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.contaccontainerblack,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),

                      ],),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientDetails()));

                      },
                      child: Container(
                          height: 45,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                          width: MediaQuery.of(context).size.width,
                          child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.lightwhite,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        ),
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.contaccontainerred,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        )
                      ],)
                  ],
                ),
              )
              ),
            ],
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: Container(
          // height: 45,
          width: MediaQuery.of(context).size.width/1,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
          child: ExpansionTile(
            trailing: Image.asset("assets/calling.png", scale: 1.1,),
            title:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

              ],
            ),
            children: [
              ListTile(title: Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {

                            Navigator.push(context, MaterialPageRoute(builder: (context)=>FinalJobsScreen()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Final Jobs',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.AppbtnColor,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>TeamAllotment()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Team Allotment',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.contaccontainerblack,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),

                      ],),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientDetails()));

                      },
                      child: Container(
                          height: 45,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                          width: MediaQuery.of(context).size.width,
                          child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.lightwhite,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        ),
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.contaccontainerred,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        )
                      ],)
                  ],
                ),
              )
              ),
            ],
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: Container(
          // height: 45,
          width: MediaQuery.of(context).size.width/1,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
          child: ExpansionTile(
            trailing: Image.asset("assets/calling.png", scale: 1.1,),
            title:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

              ],
            ),
            children: [
              ListTile(title: Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {

                            Navigator.push(context, MaterialPageRoute(builder: (context)=>FinalJobsScreen()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Final Jobs',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.AppbtnColor,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>TeamAllotment()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Team Allotment',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.contaccontainerblack,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),

                      ],),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientDetails()));

                      },
                      child: Container(
                          height: 45,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                          width: MediaQuery.of(context).size.width,
                          child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.lightwhite,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        ),
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.contaccontainerred,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        )
                      ],)
                  ],
                ),
              )
              ),
            ],
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: Container(
          // height: 45,
          width: MediaQuery.of(context).size.width/1,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
          child: ExpansionTile(
            trailing: Image.asset("assets/calling.png", scale: 1.1,),
            title:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

              ],
            ),
            children: [
              ListTile(title: Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {

                            Navigator.push(context, MaterialPageRoute(builder: (context)=>FinalJobsScreen()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Final Jobs',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.AppbtnColor,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>TeamAllotment()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Team Allotment',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.contaccontainerblack,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),

                      ],),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientDetails()));

                      },
                      child: Container(
                          height: 45,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                          width: MediaQuery.of(context).size.width,
                          child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.lightwhite,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        ),
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.contaccontainerred,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        )
                      ],)
                  ],
                ),
              )
              ),
            ],
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: Container(
          // height: 45,
          width: MediaQuery.of(context).size.width/1,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
          child: ExpansionTile(
            trailing: Image.asset("assets/calling.png", scale: 1.1,),
            title:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

              ],
            ),
            children: [
              ListTile(title: Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {

                            Navigator.push(context, MaterialPageRoute(builder: (context)=>FinalJobsScreen()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Final Jobs',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.AppbtnColor,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>TeamAllotment()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Team Allotment',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.contaccontainerblack,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),

                      ],),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientDetails()));

                      },
                      child: Container(
                          height: 45,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                          width: MediaQuery.of(context).size.width,
                          child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.lightwhite,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        ),
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.contaccontainerred,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        )
                      ],)
                  ],
                ),
              )
              ),
            ],
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: Container(
          // height: 45,
          width: MediaQuery.of(context).size.width/1,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
          child: ExpansionTile(
            trailing: Image.asset("assets/calling.png", scale: 1.1,),
            title:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

              ],
            ),
            children: [
              ListTile(title: Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {

                            Navigator.push(context, MaterialPageRoute(builder: (context)=>FinalJobsScreen()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Final Jobs',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.AppbtnColor,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>TeamAllotment()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Team Allotment',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.contaccontainerblack,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),

                      ],),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientDetails()));

                      },
                      child: Container(
                          height: 45,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                          width: MediaQuery.of(context).size.width,
                          child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.lightwhite,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        ),
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.contaccontainerred,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        )
                      ],)
                  ],
                ),
              )
              ),
            ],
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: Container(
          // height: 45,
          width: MediaQuery.of(context).size.width/1,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.lightwhite),
          child: ExpansionTile(
            trailing: Image.asset("assets/calling.png", scale: 1.1,),
            title:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Dhaval Patel", style: TextStyle(color: AppColors.textclr,fontSize: 13),),
                Text("Mumbai", style: TextStyle(color: AppColors.textclr,fontSize: 13)),

              ],
            ),
            children: [
              ListTile(title: Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(color: AppColors.contaccontainer,borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {

                            Navigator.push(context, MaterialPageRoute(builder: (context)=>FinalJobsScreen()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Final Jobs',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.AppbtnColor,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>TeamAllotment()));

                          },
                          child: Container(

                              height: 40,
                              width: MediaQuery.of(context).size.width/2.9,
                              child: Center(
                                child: Text(
                                  'Team Allotment',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.contaccontainerblack,
                                // border: Border.all(color: AppColors.AppbtnColor),
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),

                      ],),
                    SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientDetails()));

                      },
                      child: Container(
                          height: 45,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                          width: MediaQuery.of(context).size.width,
                          child: Center(child: Text("Account", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.lightwhite,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Edit",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        ),
                        Container(
                          height: 30,
                          width: 80,
                          decoration: BoxDecoration(
                              color: AppColors.contaccontainerred,
                              borderRadius: BorderRadius.circular(5)
                          ),
                          child: Center(child: Text("Delete",style: TextStyle(color: AppColors.textclr,fontWeight: FontWeight.bold),),),
                        )
                      ],)
                  ],
                ),
              )
              ),
            ],
          ),
        ),
      ),


    ]);
  }


  @override
  Widget build(BuildContext context) {
    return GetBuilder(
      init:addPhotographerController(),
      builder: (controller) {
      return Scaffold(
        backgroundColor: Color(0xff5A5959),
        // bottomNavigationBar: bottomBar(),
        appBar: isSelected ?  AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Color(0xff303030),
          actions: const [
            Padding(
              padding: EdgeInsets.all(15),
              child: Center(child: Text("Photographers Contacts",
                  style: TextStyle(fontSize: 16, color:Color(0xff1E90FF), fontWeight: FontWeight.bold)
              ),
              ),
            ),
          ],
        ) : AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Color(0xff303030),
          actions: const [
            Padding(
              padding: EdgeInsets.all(15),
              child: Center(child: Text("Clients Contacts",
                  style: TextStyle(fontSize: 16, color:Color(0xff1E90FF), fontWeight: FontWeight.bold)
              ),
              ),
            ),
          ],
        ),
        floatingActionButton: Container(
          // padding: EdgeInsets.only(bottom: 100.0),
          child: Align(
              alignment: Alignment.bottomCenter,
              child:  isSelected ? FloatingActionButton(
                child: Icon(Icons.add,size: 40,),
                onPressed: () {
                  // showModalBottomSheet<void>(
                  //   isScrollControlled: true,
                  //   context: context,
                  //   shape: RoundedRectangleBorder(
                  //     borderRadius: BorderRadius.only(
                  //         topLeft: Radius.circular(30.0),
                  //         topRight: Radius.circular(30.0)),
                  //   ),
                  //   builder: (BuildContext context) {
                  //     return Padding(
                  //         padding: MediaQuery.of(context).viewInsets,
                  //         child: Container(
                  //             child: Wrap(
                  //               children: <Widget>[
                  //                 TextField(
                  //                   decoration: InputDecoration(
                  //                       border: InputBorder.none,
                  //                       hintText: 'Enter a search term'),
                  //                 ),
                  //                 TextField(
                  //                   decoration: InputDecoration(
                  //                       border: InputBorder.none,
                  //                       hintText: 'Enter a search term'),
                  //                 ),
                  //                 TextField(
                  //                   decoration: InputDecoration(
                  //                       border: InputBorder.none,
                  //                       hintText: 'Enter a search term'),
                  //                 ),
                  //                 TextField(
                  //                   decoration: InputDecoration(
                  //                       border: InputBorder.none,
                  //                       hintText: 'Enter a search term'),
                  //                 )
                  //               ],
                  //             )));
                  //   },
                  // );
                  showModalBottomSheet<void>(
                    isScrollControlled: true,
                    context: context,
                    builder: (BuildContext context) {
                      return SingleChildScrollView(
                        child: Padding(
                          padding: MediaQuery.of(context).viewInsets,
                          // padding: const EdgeInsets.all(8.0),
                          child: Container(
                            // height: MediaQuery.of(context).size.height,
                            color: AppColors.teamcard2,
                            child: Center(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 8.0,vertical: 15),
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                        height: 35,
                                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color:  AppColors.AppbtnColor),
                                        width: MediaQuery.of(context).size.width/1.9,
                                        child: Center(child: Text("Photographer", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                                    ),
                                    SizedBox(height: 15,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            width: MediaQuery.of(context).size.width/2.2,
                                            height: 34,
                                            padding: EdgeInsets.symmetric(vertical: 0),
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(5),
                                                color: AppColors.cardclr),
                                            child: TextFormField(
                                              style: TextStyle(color: AppColors.textclr),
                                              controller:controller.firstnameController,
                                              keyboardType: TextInputType.name,
                                              decoration: InputDecoration(
                                                  hintText: 'First Name',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                                  border: InputBorder.none,
                                                  contentPadding: EdgeInsets.only(left: 10,bottom: 16)
                                              ),
                                            ),
                                          ),
                                          Container(
                                            width: MediaQuery.of(context).size.width/2.2,
                                            height: 34,
                                            padding: EdgeInsets.symmetric(vertical: 0),
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(5),
                                                color: AppColors.cardclr),
                                            child: Center(
                                              child: TextFormField(
                                                style: TextStyle(color: AppColors.textclr),
                                                controller: controller.lastnameController,
                                                keyboardType: TextInputType.name,
                                                decoration: InputDecoration(
                                                    hintText: 'Last Name(Surname)',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                                    border: InputBorder.none,
                                                    contentPadding: EdgeInsets.only(left: 9,bottom: 17)
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 9,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                      child: Container(
                                        width: MediaQuery.of(context).size.width,
                                        height: 34,
                                        padding: EdgeInsets.symmetric(vertical: 0),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(5),
                                            color: AppColors.cardclr),
                                        child: TextFormField(
                                          style: TextStyle(color: AppColors.textclr),
                                          controller: controller.mobileController,
                                          keyboardType: TextInputType.name,
                                          decoration: InputDecoration(
                                              hintText: 'Phone Number',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                              border: InputBorder.none,
                                              contentPadding: EdgeInsets.only(left: 10,bottom: 16)
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 9,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                      child: Container(
                                        width: MediaQuery.of(context).size.width,
                                        height: 34,
                                        padding: EdgeInsets.symmetric(vertical: 0),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(5),
                                            color: AppColors.cardclr),
                                        child: TextFormField(
                                          style: TextStyle(color: AppColors.textclr),
                                          controller: controller.cityController,
                                          keyboardType: TextInputType.name,
                                          decoration: InputDecoration(
                                              hintText: 'City',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                              border: InputBorder.none,
                                              contentPadding: EdgeInsets.only(left: 10,bottom: 16)
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 9,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                      child: Container(
                                        width: MediaQuery.of(context).size.width,
                                        height: 34,
                                        padding: EdgeInsets.symmetric(vertical: 0),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(5),
                                            color: AppColors.cardclr),
                                        child: TextFormField(
                                          style: TextStyle(color: AppColors.textclr),
                                          controller: controller.photogreaphertypeController,
                                          keyboardType: TextInputType.name,
                                          decoration: InputDecoration(
                                              hintText: 'Type Of Photographer',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                              border: InputBorder.none,
                                              contentPadding: EdgeInsets.only(left: 10,bottom: 16)
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 9,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                      child: Container(
                                        width: MediaQuery.of(context).size.width,
                                        height: 34,
                                        padding: EdgeInsets.symmetric(vertical: 0),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(5),
                                            color: AppColors.cardclr),
                                        child: TextFormField(
                                          style: TextStyle(color: AppColors.textclr),
                                          controller: controller.companyController,
                                          keyboardType: TextInputType.name,
                                          decoration: InputDecoration(
                                              hintText: 'Company Name (Optional)',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                              border: InputBorder.none,
                                              contentPadding: EdgeInsets.only(left: 10,bottom: 16)
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 9,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                      child: Container(
                                        width: MediaQuery.of(context).size.width,
                                        height: 34,
                                        padding: EdgeInsets.symmetric(vertical: 0),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(5),
                                            color: AppColors.cardclr),
                                        child: TextFormField(
                                          style: TextStyle(color: AppColors.textclr),
                                          controller: controller.perdayController,
                                          keyboardType: TextInputType.name,
                                          decoration: InputDecoration(
                                              hintText: 'Add Per Day Charges',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                              border: InputBorder.none,
                                              contentPadding: EdgeInsets.only(left: 10,bottom: 16)
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 40,),

                                    InkWell(
                                      onTap: (){

                                        controller.AddPhotographerr();
                                        controller.onTapClear();

                                        Get.back();
                                      },
                                      child: Container(
                                          height: 55,
                                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                                          width: MediaQuery.of(context).size.width/1.5,
                                          child: Center(child: Text("Add", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                                      ),
                                    ),

                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ) :  FloatingActionButton(
                child: Icon(Icons.add,size: 40,),
                onPressed: () {
                  showModalBottomSheet<void>(
                    isScrollControlled: true,
                    context: context,
                    builder: (BuildContext context) {
                      return SingleChildScrollView(
                        child: Padding(
                          padding: MediaQuery.of(context).viewInsets,
                          // padding: const EdgeInsets.all(8.0),
                          child: Container(
                            // height: MediaQuery.of(context).size.height,
                            color: AppColors.teamcard2,
                            child: Center(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 8.0,vertical: 15),
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                        height: 35,
                                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color:  AppColors.AppbtnColor),
                                        width: MediaQuery.of(context).size.width/2.5,
                                        child: Center(child: Text("Client", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                                    ),
                                    SizedBox(height: 15,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            width: MediaQuery.of(context).size.width/2.2,
                                            height: 34,
                                            padding: EdgeInsets.symmetric(vertical: 0),
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(5),
                                                color: AppColors.cardclr),
                                            child: TextFormField(
                                              style: TextStyle(color: AppColors.textclr),
                                              // controller: nameController,
                                              keyboardType: TextInputType.name,
                                              decoration: InputDecoration(
                                                  hintText: 'First Name',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                                  border: InputBorder.none,
                                                  contentPadding: EdgeInsets.only(left: 10,bottom: 16)
                                              ),
                                            ),
                                          ),
                                          Container(
                                            width: MediaQuery.of(context).size.width/2.2,
                                            height: 34,
                                            padding: EdgeInsets.symmetric(vertical: 0),
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(5),
                                                color: AppColors.cardclr),
                                            child: Center(
                                              child: TextFormField(
                                                style: TextStyle(color: AppColors.textclr),
                                                // controller: nameController,
                                                keyboardType: TextInputType.name,
                                                decoration: InputDecoration(
                                                    hintText: 'Last Name(Surname)',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                                    border: InputBorder.none,
                                                    contentPadding: EdgeInsets.only(left: 9,bottom: 17)
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 9,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                      child: Container(
                                        width: MediaQuery.of(context).size.width,
                                        height: 34,
                                        padding: EdgeInsets.symmetric(vertical: 0),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(5),
                                            color: AppColors.cardclr),
                                        child: TextFormField(
                                          style: TextStyle(color: AppColors.textclr),
                                          // controller: nameController,
                                          keyboardType: TextInputType.name,
                                          decoration: InputDecoration(
                                              hintText: 'Phone Number',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                              border: InputBorder.none,
                                              contentPadding: EdgeInsets.only(left: 10,bottom: 16)
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 9,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                      child: Container(
                                        width: MediaQuery.of(context).size.width,
                                        height: 34,
                                        padding: EdgeInsets.symmetric(vertical: 0),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(5),
                                            color: AppColors.cardclr),
                                        child: TextFormField(
                                          style: TextStyle(color: AppColors.textclr),
                                          // controller: nameController,
                                          keyboardType: TextInputType.name,
                                          decoration: InputDecoration(
                                              hintText: 'City',hintStyle: TextStyle(color: AppColors.textclr,fontSize: 14),
                                              border: InputBorder.none,
                                              contentPadding: EdgeInsets.only(left: 10,bottom: 16)
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 40,),

                                    InkWell(
                                      onTap: (){
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                          height: 55,
                                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(50), color:  AppColors.pdfbtn),
                                          width: MediaQuery.of(context).size.width/1.5,
                                          child: Center(child: Text("Add", style: TextStyle(fontSize: 18, color: AppColors.textclr)))
                                      ),
                                    ),

                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              )
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,

        body: Container(
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  height: 10,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          color: AppColors.containerclr,
                          borderRadius: BorderRadius.circular(10)),

                      child: Row(
                        children: [
                          InkWell(
                            onTap: () {
                              setState(() {
                                isSelected = true;
                              });
                            },
                            child: Container(
                                height: 40,
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 10, left: 10, right: 10),
                                  child: Text(
                                    'Photographers',
                                    style: TextStyle(
                                      color: isSelected
                                          ? Color(0xffffffff)
                                          : Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? AppColors.AppbtnColor
                                      : AppColors.containerclr,
                                  // border: Border.all(color: AppColors.AppbtnColor),
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          InkWell(
                            onTap: () {
                              setState(() {
                                // Navigator.of(context).push(MaterialPageRoute(
                                //   builder: (context) => NextPage(),
                                // ));
                                isSelected = false;
                              });
                            },
                            child: Container(
                                height: 40,
                                width: 90,
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 10, left: 10, right: 10),
                                  child: Text(
                                    'Clients',
                                    style: TextStyle(
                                      color: isSelected
                                          ? AppColors.whit
                                          : Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                    color: isSelected
                                        ? AppColors.containerclr
                                        : AppColors.AppbtnColor,
                                    borderRadius: BorderRadius.circular(10))),
                          ),
                        ],
                      ),)

                  ],
                ),
                SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Container(
                    height: 45,
                    // width: MediaQuery.of(context).size.width/1.1,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.darkblakcolor),
                    child: TextFormField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.search,color: AppColors.textclr,),
                        hintText: "Name, City Type of Photographers Company Name", hintStyle: TextStyle(color: AppColors.greyColor),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                isSelected ? _phptographers() : _clients(),
              ],
            ),
          ),
        ),
      );
    },);
  }

}
