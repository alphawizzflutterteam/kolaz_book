

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../Controller/edit_profile_controller.dart';
import '../../Utils/colors.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {


  @override
  Widget build(BuildContext context) {
    return GetBuilder(
      init: EditProfileController(),
      builder: (controller) {
      return Scaffold(
        backgroundColor: Color(0xff5A5959),
        // appBar: AppBar(
        //   leading: Icon(Icons.arrow_back_ios, color: Color(0xff1E90FF ),),
        //   backgroundColor: Color(0xff303030),
        //   actions: const [
        //     Padding(
        //       padding: EdgeInsets.all(15),
        //       child: Center(child: Text("Profile Setting", style: TextStyle(fontSize: 15, color:Color(0xff1E90FF ), fontWeight: FontWeight.bold), )),
        //     ),
        //   ],
        // ),
        body:
        SingleChildScrollView(
          child: Column(
            children: [
              Container(
                height: 120,
                child: Stack(children: [
                  Container(
                    color: AppColors.secondary,
                    height: 80,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 18.0,right: 10,left: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Icon(Icons.arrow_back_ios,size: 30, color: Color(0xff1E90FF ),)),
                          Text("Profile Setting",style: TextStyle(color: AppColors.AppbtnColor,fontSize: 16),)
                        ],),
                    ),
                  ),
                  Positioned(
                    top: 50 ,
                    left: 0,
                    right: 0,
                    child: Column(children: [
                      GestureDetector(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (c)=>EditProfileScreen()));
                        },
                        child: Stack(
                          children: [
                            CircleAvatar(
                                radius: 35,
                                backgroundImage:
                                AssetImage('assets/Google.png',)),
                            Positioned(
                                top: 40,
                                left: 40,
                                child: Container(

                                    decoration: BoxDecoration(
                                        color: Colors.white,

                                        borderRadius: BorderRadius.circular(13)),
                                    height: 25,width: 25,
                                    child: Icon(Icons.edit)))


                          ],),
                      ),

                      // SizedBox(height: 10,),
                      Padding(
                        padding: const EdgeInsets.only(left: 10, top: 20),
                        child: Column(
                          children: [
                            Text("Shivai Verma", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xff1E90FF)),),
                            SizedBox(height: 5,),
                            Text("ID-001", style: TextStyle(fontSize: 15, color: Colors.white),),
                            Padding(
                              padding: const EdgeInsets.only(left: 80),
                              child: Row(
                                children: [
                                  Text("Subscripation 14 Days Free Trial", style: TextStyle(fontSize: 15, color: Colors.white),),
                                  SizedBox(width: 6,),
                                  Text("Buy", style: TextStyle(fontSize: 15, color: Color(0xff1E90FF), decoration: TextDecoration.underline,),)
                                ],
                              ),
                            ),
                            SizedBox(height: 10,),
                            Container(
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Color(0xff303030)),
                                height: 50,
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Center(child: Text("Your Details", style: TextStyle(fontSize: 18, color: Color(0xff1E90FF))))
                            ),
                            SizedBox(height: 5,),
                            Padding(
                              padding: const EdgeInsets.only(left: 13, right: 40),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("First Name", style: TextStyle(color: Color(0xffCCCCCC)),),
                                  // SizedBox(width: 15),
                                  Text("Last Name(Surname)", style: TextStyle(color: Color(0xffCCCCCC)),)
                                ],
                              ),
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: MediaQuery.of(context).size.width/2,
                                      child: Card(
                                        color:  Color(0xff6D6A6A),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(10.0),
                                        ),
                                        elevation: 5,
                                        child: TextFormField(
                                          style: TextStyle(color: AppColors.whit),
                                          // controller: nameController,
                                          keyboardType: TextInputType.name,
                                          decoration: InputDecoration(
                                              hintText: 'Shivani',hintStyle: TextStyle(color: AppColors.whit),
                                              border: InputBorder.none,
                                              contentPadding: EdgeInsets.only(left: 10)
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 10,),
                                    Container(
                                      width: MediaQuery.of(context).size.width/2.5,
                                      child: Card(
                                        color: Color(0xff6D6A6A),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(10.0),
                                        ),
                                        elevation: 5,
                                        child: TextFormField(
                                          style: TextStyle(color: AppColors.whit),
                                          // controller: nameController,
                                          keyboardType: TextInputType.name,

                                          decoration: InputDecoration(
                                              hintText: 'Verma',hintStyle: TextStyle(fontSize: 14, color:  Color(0xffFFFFFF)),
                                              border: InputBorder.none,
                                              contentPadding: EdgeInsets.only(left: 10)
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 9,),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text("Phone Number(Not Editable)", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC))),
                                      SizedBox(height: 5,),
                                      Container(
                                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Color(0xff6D6A6A)),
                                        height: 50,
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Padding(
                                          padding: const EdgeInsets.only(left: 10, top: 15),
                                          child: Text("+91 9809890980", style: TextStyle(fontSize: 14, color:  Color(0xffFFFFFF), ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 5,),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 8),
                                        child: Text("Email Id", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                                      ),
                                      SizedBox(width: 10,),
                                      Container(
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            style: TextStyle(color: AppColors.whit),
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'shivani@gmail.com',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 10,),
                                      Container(
                                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Color(0xff303030)),
                                        height: 50,
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Center(
                                          child: Text("Company Details", style: TextStyle(fontSize: 14, color:  Color(0xff1E90FF), fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 5,),
                                      SizedBox(width: 10,),
                                      Container(
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'Company Name',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 5,),
                                      Container(
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'Company Phone Number',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 5,),
                                      Container(
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'Company Address',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 5,),
                                      Container(
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'Country',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 5,),
                                      Container(height: 80,
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'Upload Company logo',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 10),
                                        child: Text("Company Website Link/ Email Id", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                                      ),
                                      Container(
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'Enter Link / Email Id',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 10),
                                        child: Text("FaceBook Page Link", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                                      ),
                                      Container(
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'Paste here facebook page link',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 10),
                                        child: Text("Instagram Page Link", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                                      ),
                                      Container(
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'Paste here instagram page link',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 10),
                                        child: Text("Youtube Channel Link", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                                      ),
                                      Container(
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'Paste here Youtube Channel link',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 10),
                                        child: Text("Terms & Condition For Quotation PDF", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                                      ),
                                      Container(
                                        width: MediaQuery.of(context).size.width/1.1,
                                        child: Card(
                                          color: Color(0xff6D6A6A),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 5,
                                          child: TextFormField(
                                            // controller: nameController,
                                            keyboardType: TextInputType.name,
                                            decoration: InputDecoration(
                                                hintText: 'Paste here from Notepad/ Text File',hintStyle: TextStyle(color: AppColors.whit),
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(left: 10)
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 10,),
                      Container(
                        height: 40,
                        width: MediaQuery.of(context).size.width/2.2,
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Color(0xff1E90FF)),
                        child: Center(child: Text("Edit / Update",
                          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18, color: Colors.white),
                        ),
                        ),
                      ),
                    ],),)
                ],),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 20),
                child: Column(
                  children: [
                    Text("Shivai Verma", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xff1E90FF)),),
                    SizedBox(height: 5,),
                    Text("ID-001", style: TextStyle(fontSize: 15, color: Colors.white),),
                    Padding(
                      padding: const EdgeInsets.only(left: 80),
                      child: Row(
                        children: [
                          Text("Subscripation 14 Days Free Trial", style: TextStyle(fontSize: 15, color: Colors.white),),
                          SizedBox(width: 6,),
                          Text("Buy", style: TextStyle(fontSize: 15, color: Color(0xff1E90FF), decoration: TextDecoration.underline,),)
                        ],
                      ),
                    ),
                    SizedBox(height: 10,),
                    Container(
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Color(0xff303030)),
                        height: 50,
                        width: MediaQuery.of(context).size.width/1.1,
                        child: Center(child: Text("Your Details", style: TextStyle(fontSize: 18, color: Color(0xff1E90FF))))
                    ),
                    SizedBox(height: 5,),
                    Padding(
                      padding: const EdgeInsets.only(left: 13, right: 55),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("First Name", style: TextStyle(color: Color(0xffCCCCCC)),),
                          // SizedBox(width: 15),
                          Text("Last Name(Surname)", style: TextStyle(color: Color(0xffCCCCCC)),)
                        ],
                      ),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        Row(
                          // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 5.0),
                              child: Container(
                                width: MediaQuery.of(context).size.width/2.2,
                                child: Card(
                                  color:  Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Shivani',
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            // SizedBox(width: 0.5,),
                            Container(
                              width: MediaQuery.of(context).size.width/2.2,
                              child: Card(
                                color: Color(0xff6D6A6A),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                elevation: 5,
                                child: TextFormField(
                                  // controller: nameController,
                                  keyboardType: TextInputType.name,
                                  decoration: InputDecoration(
                                      hintText: 'Verma',
                                      border: InputBorder.none,
                                      contentPadding: EdgeInsets.only(left: 10)
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 9,),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Phone Number(Not Editable)", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC))),
                              SizedBox(height: 5,),
                              Container(
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Color(0xff6D6A6A)),
                                height: 50,
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 10, top: 15),
                                  child: Text("+91 9809890980", style: TextStyle(fontSize: 14, color:  Color(0xffFFFFFF), ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 5,),
                              Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Text("Email Id", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                              ),
                              SizedBox(width: 10,),
                              Container(
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintStyle: TextStyle(color: AppColors.whit),
                                        hintText: 'mailto:shivani@gmail.com',
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 10,),
                              Container(
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Color(0xff303030)),
                                height: 50,
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Center(
                                  child: Text("Company Details", style: TextStyle(fontSize: 14, color:  Color(0xff1E90FF), fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),
                              SizedBox(height: 5,),
                              SizedBox(width: 10,),
                              Container(
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Company Name',
                                        hintStyle: TextStyle(color: AppColors.whit),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 5,),
                              Container(
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Company Phone Number',
                                        hintStyle: TextStyle(color: AppColors.whit),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 5,),
                              Container(
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Company Address',hintStyle: TextStyle(color: AppColors.whit),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 5,),
                              Container(
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Country',hintStyle: TextStyle(color: AppColors.whit),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 5,),
                              Container(height: 80,
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Upload Company logo',hintStyle: TextStyle(color: AppColors.whit),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Text("Company Website Link/ Email Id", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Enter Link / Email Id',hintStyle: TextStyle(color: AppColors.whit),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Text("FaceBook Page Link", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Paste here facebook page link',hintStyle: TextStyle(color: AppColors.whit),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Text("Instagram Page Link", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Paste here instagram page link',hintStyle: TextStyle(color: AppColors.whit),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Text("Youtube Channel Link", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Paste here Youtube Channel link',hintStyle: TextStyle(color: AppColors.whit),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Text("Terms & Condition For Quotation PDF", style: TextStyle(fontSize: 14, color: Color(0xffCCCCCC)),),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width/1.1,
                                child: Card(
                                  color: Color(0xff6D6A6A),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  elevation: 5,
                                  child: TextFormField(
                                    // controller: nameController,
                                    keyboardType: TextInputType.name,
                                    decoration: InputDecoration(
                                        hintText: 'Paste here from Notepad/ Text File',hintStyle: TextStyle(color: AppColors.whit),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.only(left: 10)
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10,),
              Container(
                height: 40,
                width: MediaQuery.of(context).size.width/2.2,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Color(0xff1E90FF)),
                child: Center(child: Text("Edit / Update",
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18, color: Colors.white),
                ),
                ),
              ),
            ],
          ),
        ),
      );
    },);
  }
}
