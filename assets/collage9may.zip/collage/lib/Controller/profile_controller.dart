import 'appbased_controller/appbase_controller.dart';

class ProfileController extends AppBaseController {


}