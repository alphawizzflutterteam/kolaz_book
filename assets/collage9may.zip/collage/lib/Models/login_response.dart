// To parse this JSON data, do
//
//     final loginResponseModel = loginResponseModelFromJson(jsonString);

import 'dart:convert';

LoginResponseModel loginResponseModelFromJson(String str) => LoginResponseModel.fromJson(json.decode(str));

String loginResponseModelToJson(LoginResponseModel data) => json.encode(data.toJson());

class LoginResponseModel {
  bool? error;
  String? message;
  LoginData? data;

  LoginResponseModel({
     this.error,
     this.message,
     this.data,
  });

  factory LoginResponseModel.fromJson(Map<String, dynamic> json) => LoginResponseModel(
    error: json["error"],
    message: json["message"],
    data: LoginData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "error": error,
    "message": message,
    "data": data!.toJson(),
  };
}

class LoginData {
  String? otp;
  String? id;
  String? username;
  String? email;
  String? fname;
  String? lname;
  String? countrycode;
  String? currency;
  String? mobile;
  String? password;
  String? profilePic;
  String? facebookId;
  String? type;
  String? isGold;
  String? address;
  String? city;
  String? country;
  String? deviceToken;
  String? date;
  String? agreecheck;
  String? status;
  String? wallet;
  DateTime? createdAt;
  DateTime? updatedAt;

  LoginData({
    this.otp,
    this.id,
    this.username,
    this.email,
    this.fname,
    this.lname,
    this.countrycode,
    this.currency,
    this.mobile,
    this.password,
    this.profilePic,
    this.facebookId,
    this.type,
    this.isGold,
    this.address,
    this.city,
    this.country,
    this.deviceToken,
    this.date,
    this.agreecheck,
    this.status,
    this.wallet,

    this.createdAt,
    this.updatedAt,
  });

  factory LoginData.fromJson(Map<String, dynamic> json) => LoginData(
    otp: json["otp"],
    id: json["id"],
    username: json["username"],
    email: json["email"],
    fname: json["fname"],
    lname: json["lname"],
    countrycode: json["countrycode"],
    currency: json["currency"],
    mobile: json["mobile"],
    password: json["password"],
    profilePic: json["profile_pic"],
    facebookId: json["facebook_id"],
    type: json["type"],
    isGold: json["isGold"],
    address: json["address"],
    city: json["city"],
    country: json["country"],
    deviceToken: json["device_token"],
    date: json["date"],
    agreecheck: json["agreecheck"],
    status: json["status"],
    wallet: json["wallet"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "otp":otp,
    "id": id,
    "username": username,
    "email": email,
    "fname": fname,
    "lname": lname,
    "countrycode": countrycode,
    "currency": currency,
    "mobile": mobile,
    "password": password,
    "profile_pic": profilePic,
    "facebook_id": facebookId,
    "type": type,
    "isGold": isGold,
    "address": address,
    "city": city,
    "country": country,
    "device_token": deviceToken,
    "date": date,
    "agreecheck": agreecheck,
    "status": status,
    "wallet": wallet,


    "created_at": createdAt!.toIso8601String(),
    "updated_at": updatedAt!.toIso8601String(),
  };
}
