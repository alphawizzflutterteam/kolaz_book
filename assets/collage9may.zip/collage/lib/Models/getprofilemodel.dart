// To parse this JSON data, do
//
//     final getProfilemodel = getProfilemodelFromJson(jsonString);

import 'dart:convert';

GetProfilemodel getProfilemodelFromJson(String str) => GetProfilemodel.fromJson(json.decode(str));

String getProfilemodelToJson(GetProfilemodel data) => json.encode(data.toJson());

class GetProfilemodel {
  bool? error;
  String? message;
  Data? data;

  GetProfilemodel({
    this.error,
    this.message,
    this.data,
  });

  factory GetProfilemodel.fromJson(Map<String, dynamic> json) => GetProfilemodel(
    error: json["error"],
    message: json["message"],
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "error": error,
    "message": message,
    "data": data?.toJson(),
  };
}

class Data {
  String? firstname;
  String? lastname;
  String? email;
  String? mobile;
  String? profilePic;

  Data({
    this.firstname,
    this.lastname,
    this.email,
    this.mobile,
    this.profilePic,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    firstname: json["firstname"],
    lastname: json["lastname"],
    email: json["email"],
    mobile: json["mobile"],
    profilePic: json["profile_pic"],
  );

  Map<String, dynamic> toJson() => {
    "firstname": firstname,
    "lastname": lastname,
    "email": email,
    "mobile": mobile,
    "profile_pic": profilePic,
  };
}
