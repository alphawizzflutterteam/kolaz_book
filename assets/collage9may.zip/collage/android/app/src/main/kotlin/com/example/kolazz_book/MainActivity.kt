package com.example.kolazz_book

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
